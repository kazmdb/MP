// Configuración de Firebase
// Credenciales del proyecto peluqueriamartin-beefb
const firebaseConfig = {
    apiKey: "AIzaSyDuuqx99GlvurjAem7RxuRucyGLkM6fIG4",
    authDomain: "peluqueriamartin-beefb.firebaseapp.com",
    projectId: "peluqueriamartin-beefb",
    storageBucket: "peluqueriamartin-beefb.firebasestorage.app",
    messagingSenderId: "992167746012",
    appId: "1:992167746012:web:fdcabb47a07421dc955719",
    measurementId: "G-41676SSJVH"
};

// Configuración de caché
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutos en milisegundos

// Función para verificar si el caché es válido
function isCacheValid(timestamp) {
    if (!timestamp) return false;
    const now = Date.now();
    return (now - timestamp) < CACHE_DURATION;
}

// Función para obtener datos del caché
function getFromCache(key) {
    try {
        const cached = localStorage.getItem(key);
        if (!cached) return null;
        const data = JSON.parse(cached);
        if (isCacheValid(data.timestamp)) {
            console.log(`Usando caché para ${key}`);
            return data.value;
        }
        return null;
    } catch (error) {
        console.error(`Error al leer caché ${key}:`, error);
        return null;
    }
}

// Función para guardar datos en caché
function saveToCache(key, value) {
    try {
        const data = {
            value: value,
            timestamp: Date.now()
        };
        localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
        console.error(`Error al guardar caché ${key}:`, error);
    }
}

// Función para invalidar caché
function invalidateCache(key) {
    try {
        localStorage.removeItem(key);
    } catch (error) {
        console.error(`Error al invalidar caché ${key}:`, error);
    }
}

// Inicializar Firebase
try {
    firebase.initializeApp(firebaseConfig);
    console.log('Firebase inicializado correctamente');
} catch (error) {
    console.error('Error al inicializar Firebase:', error);
}

// Inicializar Firestore
let db;
try {
    db = firebase.firestore();
    console.log('Firestore inicializado correctamente');
} catch (error) {
    console.error('Error al inicializar Firestore:', error);
}

// Función para guardar reserva en Firebase
async function guardarReservaFirebase(reserva) {
    try {
        console.log('=== GUARDANDO RESERVA EN FIREBASE ===');
        console.log('Datos de reserva:', reserva);

        if (!db) {
            throw new Error('Firestore no está inicializado');
        }

        // Obtener configuración de WhatsApp (opcional)
        const configWhatsApp = await obtenerConfiguracionWhatsApp();
        const whatsappActivo = configWhatsApp && configWhatsApp.activo;

        console.log('Configuración WhatsApp:', configWhatsApp);
        console.log('WhatsApp activo:', whatsappActivo);

        const docRef = await db.collection('reservas').add({
            ...reserva,
            whatsappEnviado: false,
            whatsappActivo: whatsappActivo,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        console.log('✅ Reserva guardada con ID:', docRef.id);

        // Enviar WhatsApp si hay teléfono (siempre enviar, sin verificar configuración)
        // Buscar teléfono en ambos campos (phone y telefono)
        const telefono = reserva.telefono || reserva.phone;

        if (telefono) {
            try {
                console.log('📱 Intentando enviar WhatsApp para reserva:', docRef.id);
                console.log('📱 Teléfono:', telefono);

                const resultado = await enviarConfirmacionWhatsApp(reserva);
                console.log('📱 Resultado del envío de WhatsApp:', resultado);

                if (resultado.success) {
                    await db.collection('reservas').doc(docRef.id).update({
                        whatsappEnviado: true,
                        whatsappEnviadoEn: firebase.firestore.FieldValue.serverTimestamp()
                    });
                    console.log('✅ WhatsApp enviado exitosamente para reserva:', docRef.id);
                } else {
                    console.error('❌ Error al enviar WhatsApp:', resultado.error);
                    // No fallar la reserva si falla el WhatsApp
                }
            } catch (error) {
                console.error('❌❌ Error al enviar WhatsApp:', error);
                console.error('Error message:', error.message);
                console.error('Error stack:', error.stack);
                // No fallar la reserva si falla el WhatsApp
            }
        } else {
            console.log('⚠️ No hay teléfono para enviar WhatsApp');
            console.log('Campos disponibles:', Object.keys(reserva));
        }

        return docRef.id;
    } catch (error) {
        console.error('❌❌ Error al guardar reserva:', error);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
        throw error;
    }
}

// Función para obtener todas las reservas
async function obtenerReservasFirebase() {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        const snapshot = await db.collection('reservas')
            .orderBy('createdAt', 'desc')
            .get();

        const reservas = [];
        snapshot.forEach(doc => {
            reservas.push({
                id: doc.id,
                ...doc.data()
            });
        });

        return reservas;
    } catch (error) {
        console.error('Error al obtener reservas:', error);
        throw error;
    }
}

// Función para actualizar reserva
async function actualizarReservaFirebase(id, datos) {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        await db.collection('reservas').doc(id).update(datos);
        console.log('Reserva actualizada:', id);
    } catch (error) {
        console.error('Error al actualizar reserva:', error);
        throw error;
    }
}

// Función para eliminar reserva
async function eliminarReservaFirebase(id) {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        await db.collection('reservas').doc(id).delete();
        console.log('Reserva eliminada:', id);
    } catch (error) {
        console.error('Error al eliminar reserva:', error);
        throw error;
    }
}

// Función para guardar turnosData en Firebase
async function guardarTurnosDataFirebase(turnosData) {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        await db.collection('config').doc('turnosData').set({
            data: turnosData,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        console.log('TurnosData guardado en Firebase');

        // Invalidar caché
        invalidateCache('turnosData');
    } catch (error) {
        console.error('Error al guardar turnosData:', error);
        throw error;
    }
}

// Función para obtener turnosData de Firebase
async function obtenerTurnosDataFirebase() {
    try {
        // Verificar caché primero (con duración más corta: 1 minuto)
        const cached = getFromCache('turnosData');
        if (cached !== null) {
            return cached;
        }

        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        const doc = await db.collection('config').doc('turnosData').get();
        const result = doc.exists ? (doc.data().data || {}) : {};

        // Guardar en caché
        saveToCache('turnosData', result);

        return result;
    } catch (error) {
        console.error('Error al obtener turnosData:', error);
        return {};
    }
}

// Función para escuchar cambios en tiempo real en las reservas
function escucharReservasFirebase(callback) {
    try {
        if (!db) {
            console.error('Firestore no está inicializado, no se pueden escuchar reservas');
            return () => {}; // Retornar función de limpieza vacía
        }
        return db.collection('reservas')
            .orderBy('createdAt', 'desc')
            .onSnapshot((snapshot) => {
                const reservas = [];
                snapshot.forEach(doc => {
                    reservas.push({
                        id: doc.id,
                        ...doc.data()
                    });
                });
                callback(reservas);
            }, (error) => {
                console.error('Error al escuchar reservas:', error);
            });
    } catch (error) {
        console.error('Error al configurar escucha de reservas:', error);
        return () => {}; // Retornar función de limpieza vacía
    }
}

// Función para escuchar cambios en tiempo real en turnosData
function escucharTurnosDataFirebase(callback) {
    try {
        if (!db) {
            console.error('Firestore no está inicializado, no se pueden escuchar turnosData');
            return () => {}; // Retornar función de limpieza vacía
        }
        return db.collection('config').doc('turnosData')
            .onSnapshot((doc) => {
                const data = doc.exists ? (doc.data().data || {}) : {};
                callback(data);

                // Actualizar caché con los nuevos datos
                saveToCache('turnosData', data);
            }, (error) => {
                console.error('Error al escuchar turnosData:', error);
            });
    } catch (error) {
        console.error('Error al configurar escucha de turnosData:', error);
        return () => {}; // Retornar función de limpieza vacía
    }
}

// Función para guardar la configuración de reservas por turno
async function guardarConfigReservasPorTurno(cantidad) {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        await db.collection('config').doc('reservasPorTurno').set({
            cantidad: cantidad,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        console.log('Configuración de reservas por turno guardada:', cantidad);

        // Invalidar caché
        invalidateCache('configReservasPorTurno');
    } catch (error) {
        console.error('Error al guardar configuración de reservas por turno:', error);
        throw error;
    }
}

// Función para obtener la configuración de reservas por turno
async function obtenerConfigReservasPorTurno() {
    try {
        // Verificar caché primero
        const cached = getFromCache('configReservasPorTurno');
        if (cached !== null) {
            return cached;
        }

        if (!db) {
            console.error('Firestore no está inicializado, usando valor por defecto');
            return 1;
        }
        const doc = await db.collection('config').doc('reservasPorTurno').get();
        const result = doc.exists ? (doc.data().cantidad || 1) : 1;

        // Guardar en caché
        saveToCache('configReservasPorTurno', result);

        console.log('Configuración de reservas por turno obtenida:', result);
        return result;
    } catch (error) {
        console.error('Error al obtener configuración de reservas por turno:', error);
        return 1;
    }
}

// Función para escuchar cambios en tiempo real en la configuración de reservas por turno
function escucharConfigReservasPorTurnoFirebase(callback) {
    try {
        if (!db) {
            console.error('Firestore no está inicializado, no se pueden escuchar configuración');
            return () => {}; // Retornar función de limpieza vacía
        }
        return db.collection('config').doc('reservasPorTurno')
            .onSnapshot((doc) => {
                const data = doc.exists ? doc.data() : { cantidad: 1 };
                callback(data);

                // Actualizar caché con los nuevos datos
                saveToCache('configReservasPorTurno', data.cantidad || 1);
            }, (error) => {
                console.error('Error al escuchar configuración de reservas por turno:', error);
            });
    } catch (error) {
        console.error('Error al configurar escucha de configuración:', error);
        return () => {}; // Retornar función de limpieza vacía
    }
}

// Función para guardar la configuración de servicios
async function guardarConfigServicios(configServicios) {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        await db.collection('config').doc('servicios').set({
            data: configServicios,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        console.log('Configuración de servicios guardada');

        // Invalidar caché
        invalidateCache('configServicios');
    } catch (error) {
        console.error('Error al guardar configuración de servicios:', error);
        throw error;
    }
}

// Función para obtener la configuración de servicios
async function obtenerConfigServicios() {
    try {
        // Verificar caché primero
        const cached = getFromCache('configServicios');
        if (cached !== null) {
            return cached;
        }

        if (!db) {
            console.error('Firestore no está inicializado, usando configuración por defecto');
            return {};
        }
        const doc = await db.collection('config').doc('servicios').get();
        const result = doc.exists ? (doc.data().data || {}) : {};

        // Guardar en caché
        saveToCache('configServicios', result);

        return result;
    } catch (error) {
        console.error('Error al obtener configuración de servicios:', error);
        return {};
    }
}

// Función para escuchar cambios en tiempo real en la configuración de servicios
function escucharConfigServiciosFirebase(callback) {
    try {
        if (!db) {
            console.error('Firestore no está inicializado, no se pueden escuchar configuración de servicios');
            return () => {}; // Retornar función de limpieza vacía
        }
        return db.collection('config').doc('servicios')
            .onSnapshot((doc) => {
                const data = doc.exists ? (doc.data().data || {}) : {};
                callback(data);

                // Actualizar caché con los nuevos datos
                saveToCache('configServicios', data);
            }, (error) => {
                console.error('Error al escuchar configuración de servicios:', error);
            });
    } catch (error) {
        console.error('Error al configurar escucha de configuración de servicios:', error);
        return () => {}; // Retornar función de limpieza vacía
    }
}

// Función para guardar la configuración de horarios
async function guardarConfigHorariosFirebase(horarios) {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        await db.collection('config').doc('horarios').set({
            data: horarios,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        console.log('Configuración de horarios guardada');

        // Invalidar caché
        invalidateCache('configHorarios');
    } catch (error) {
        console.error('Error al guardar configuración de horarios:', error);
        throw error;
    }
}

// Función para obtener la configuración de horarios
async function obtenerConfigHorariosFirebase() {
    try {
        // Verificar caché primero
        const cached = getFromCache('configHorarios');
        if (cached !== null) {
            return cached;
        }

        if (!db) {
            console.error('Firestore no está inicializado, usando configuración por defecto');
            return {};
        }
        const doc = await db.collection('config').doc('horarios').get();
        const result = doc.exists ? (doc.data().data || {}) : {};

        // Guardar en caché
        saveToCache('configHorarios', result);

        return result;
    } catch (error) {
        console.error('Error al obtener configuración de horarios:', error);
        return {};
    }
}

// Función para escuchar cambios en tiempo real en la configuración de horarios
function escucharConfigHorariosFirebase(callback) {
    try {
        if (!db) {
            console.error('Firestore no está inicializado, no se pueden escuchar configuración de horarios');
            return () => {}; // Retornar función de limpieza vacía
        }
        return db.collection('config').doc('horarios')
            .onSnapshot((doc) => {
                const data = doc.exists ? (doc.data().data || {}) : {};
                callback(data);

                // Actualizar caché con los nuevos datos
                saveToCache('configHorarios', data);
            }, (error) => {
                console.error('Error al escuchar configuración de horarios:', error);
            });
    } catch (error) {
        console.error('Error al configurar escucha de configuración de horarios:', error);
        return () => {}; // Retornar función de limpieza vacía
    }
}

// Función para guardar los días cerrados
async function guardarDiasCerradosFirebase(diasCerrados) {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        await db.collection('config').doc('diasCerrados').set({
            data: diasCerrados,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        console.log('Días cerrados guardados');

        // Invalidar caché
        invalidateCache('diasCerrados');
    } catch (error) {
        console.error('Error al guardar días cerrados:', error);
        throw error;
    }
}

// Función para obtener los días cerrados
async function obtenerDiasCerradosFirebase() {
    try {
        // Verificar caché primero
        const cached = getFromCache('diasCerrados');
        if (cached !== null) {
            return cached;
        }

        if (!db) {
            console.error('Firestore no está inicializado');
            return [];
        }
        const doc = await db.collection('config').doc('diasCerrados').get();
        const result = doc.exists ? (doc.data().data || []) : [];

        // Guardar en caché
        saveToCache('diasCerrados', result);

        return result;
    } catch (error) {
        console.error('Error al obtener días cerrados:', error);
        return [];
    }
}

// Función para escuchar cambios en tiempo real en los días cerrados
function escucharDiasCerradosFirebase(callback) {
    try {
        if (!db) {
            console.error('Firestore no está inicializado, no se pueden escuchar días cerrados');
            return () => {}; // Retornar función de limpieza vacía
        }
        return db.collection('config').doc('diasCerrados')
            .onSnapshot((doc) => {
                const data = doc.exists ? (doc.data().data || []) : [];
                callback(data);

                // Actualizar caché con los nuevos datos
                saveToCache('diasCerrados', data);
            }, (error) => {
                console.error('Error al escuchar días cerrados:', error);
            });
    } catch (error) {
        console.error('Error al configurar escucha de días cerrados:', error);
        return () => {}; // Retornar función de limpieza vacía
    }
}

// Función para guardar la configuración de turnos
async function guardarConfigTurnosFirebase(configTurnos) {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        await db.collection('config').doc('turnosConfig').set({
            data: configTurnos,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        console.log('Configuración de turnos guardada');

        // Invalidar caché
        invalidateCache('configTurnos');
    } catch (error) {
        console.error('Error al guardar configuración de turnos:', error);
        throw error;
    }
}

// Función para obtener la configuración de turnos
async function obtenerConfigTurnosFirebase() {
    try {
        // Verificar caché primero
        const cached = getFromCache('configTurnos');
        if (cached !== null) {
            return cached;
        }

        if (!db) {
            console.error('Firestore no está inicializado, usando configuración por defecto');
            return {};
        }
        const doc = await db.collection('config').doc('turnosConfig').get();
        const result = doc.exists ? (doc.data().data || {}) : {};

        // Guardar en caché
        saveToCache('configTurnos', result);

        return result;
    } catch (error) {
        console.error('Error al obtener configuración de turnos:', error);
        return {};
    }
}

// Función para escuchar cambios en tiempo real en la configuración de turnos
function escucharConfigTurnosFirebase(callback) {
    try {
        if (!db) {
            console.error('Firestore no está inicializado, no se pueden escuchar configuración de turnos');
            return () => {}; // Retornar función de limpieza vacía
        }
        return db.collection('config').doc('turnosConfig')
            .onSnapshot((doc) => {
                const data = doc.exists ? (doc.data().data || {}) : {};
                callback(data);

                // Actualizar caché con los nuevos datos
                saveToCache('configTurnos', data);
            }, (error) => {
                console.error('Error al escuchar configuración de turnos:', error);
            });
    } catch (error) {
        console.error('Error al configurar escucha de configuración de turnos:', error);
        return () => {}; // Retornar función de limpieza vacía
    }
}

// Función para guardar un ingreso en Firebase
async function guardarIngresoFirebase(ingreso) {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        const docRef = await db.collection('ingresos').add({
            ...ingreso,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        console.log('Ingreso guardado con ID:', docRef.id);
        return docRef.id;
    } catch (error) {
        console.error('Error al guardar ingreso:', error);
        throw error;
    }
}

// Función para obtener ingresos de un día específico
async function obtenerIngresosPorFecha(fecha) {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        const snapshot = await db.collection('ingresos')
            .where('fecha', '==', fecha)
            .get();

        const ingresos = [];
        snapshot.forEach(doc => {
            ingresos.push({
                id: doc.id,
                ...doc.data()
            });
        });

        return ingresos;
    } catch (error) {
        console.error('Error al obtener ingresos por fecha:', error);
        return [];
    }
}

// Función para obtener el total de ingresos de un día
async function obtenerTotalIngresosPorFecha(fecha) {
    try {
        const ingresos = await obtenerIngresosPorFecha(fecha);
        const total = ingresos.reduce((sum, ingreso) => {
            const monto = parseInt(String(ingreso.monto).replace(/[^0-9]/g, '')) || 0;
            return sum + monto;
        }, 0);
        return total;
    } catch (error) {
        console.error('Error al calcular total de ingresos:', error);
        return 0;
    }
}

// Función para obtener ingresos de un rango de fechas
async function obtenerIngresosPorRango(fechaInicio, fechaFin) {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        const snapshot = await db.collection('ingresos')
            .where('fecha', '>=', fechaInicio)
            .where('fecha', '<=', fechaFin)
            .get();

        const ingresos = [];
        snapshot.forEach(doc => {
            ingresos.push({
                id: doc.id,
                ...doc.data()
            });
        });

        return ingresos;
    } catch (error) {
        console.error('Error al obtener ingresos por rango:', error);
        return [];
    }
}

// Función para obtener el total de ingresos de un rango de fechas
async function obtenerTotalIngresosPorRango(fechaInicio, fechaFin) {
    try {
        const ingresos = await obtenerIngresosPorRango(fechaInicio, fechaFin);
        const total = ingresos.reduce((sum, ingreso) => {
            const monto = parseInt(String(ingreso.monto).replace(/[^0-9]/g, '')) || 0;
            return sum + monto;
        }, 0);
        return total;
    } catch (error) {
        console.error('Error al calcular total de ingresos por rango:', error);
        return 0;
    }
}

// Función para obtener ingresos de la semana actual
async function obtenerIngresosSemanaActual() {
    try {
        const today = new Date();
        const dayOfWeek = today.getDay(); // 0 = domingo, 1 = lunes, etc.

        // Calcular el inicio de la semana (lunes)
        const startOfWeek = new Date(today);
        startOfWeek.setDate(today.getDate() - (dayOfWeek === 0 ? 6 : dayOfWeek - 1));

        // Calcular el fin de la semana (domingo)
        const endOfWeek = new Date(startOfWeek);
        endOfWeek.setDate(startOfWeek.getDate() + 6);

        const fechaInicio = startOfWeek.toISOString().split('T')[0];
        const fechaFin = endOfWeek.toISOString().split('T')[0];

        return await obtenerTotalIngresosPorRango(fechaInicio, fechaFin);
    } catch (error) {
        console.error('Error al obtener ingresos de la semana actual:', error);
        return 0;
    }
}

// Función para obtener ingresos del mes actual
async function obtenerIngresosMesActual() {
    try {
        const today = new Date();
        const year = today.getFullYear();
        const month = today.getMonth();

        // Primer día del mes
        const startOfMonth = new Date(year, month, 1);
        const fechaInicio = startOfMonth.toISOString().split('T')[0];

        // Último día del mes
        const endOfMonth = new Date(year, month + 1, 0);
        const fechaFin = endOfMonth.toISOString().split('T')[0];

        return await obtenerTotalIngresosPorRango(fechaInicio, fechaFin);
    } catch (error) {
        console.error('Error al obtener ingresos del mes actual:', error);
        return 0;
    }
}

// Función para escuchar cambios en tiempo real en los ingresos
function escucharIngresosFirebase(callback) {
    try {
        if (!db) {
            console.error('Firestore no está inicializado, no se pueden escuchar ingresos');
            return () => {}; // Retornar función de limpieza vacía
        }
        return db.collection('ingresos')
            .orderBy('createdAt', 'desc')
            .onSnapshot((snapshot) => {
                const ingresos = [];
                snapshot.forEach(doc => {
                    ingresos.push({
                        id: doc.id,
                        ...doc.data()
                    });
                });
                callback(ingresos);
            }, (error) => {
                console.error('Error al escuchar ingresos:', error);
            });
    } catch (error) {
        console.error('Error al configurar escucha de ingresos:', error);
        return () => {}; // Retornar función de limpieza vacía
    }
}

// ==================== FUNCIONES DE WHATSAPP (ULTRAMSG) ====================

// Configuración de Ultramsg
const ULTRAMSG_CONFIG = {
    instanceId: 'instance174468',
    token: '22buqtstxo87neek',
    apiUrl: 'https://api.ultramsg.com'
};

// Función para formatear número de teléfono para WhatsApp
function formatearNumeroWhatsApp(numero) {
    try {
        // Eliminar espacios, guiones y paréntesis
        let limpio = numero.replace(/[\s\-\(\)]/g, '');

        // Eliminar el + si existe
        limpio = limpio.replace(/^\+/, '');

        // Si no tiene código de país, agregar 598 (Uruguay)
        if (!limpio.startsWith('598')) {
            limpio = '598' + limpio;
        }

        return limpio;
    } catch (error) {
        console.error('Error al formatear número:', error);
        return numero;
    }
}

// Función para enviar mensaje de WhatsApp
async function enviarWhatsApp(numero, mensaje) {
    try {
        const numeroFormateado = formatearNumeroWhatsApp(numero);
        const url = `${ULTRAMSG_CONFIG.apiUrl}/${ULTRAMSG_CONFIG.instanceId}/messages/chat`;

        console.log('=== ENVIANDO WHATSAPP ===');
        console.log('Número original:', numero);
        console.log('Número formateado:', numeroFormateado);
        console.log('URL:', url);
        console.log('Mensaje:', mensaje);
        console.log('Token:', ULTRAMSG_CONFIG.token ? 'Presente' : 'Faltante');
        console.log('Instance ID:', ULTRAMSG_CONFIG.instanceId);

        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                token: ULTRAMSG_CONFIG.token,
                to: numeroFormateado,
                body: mensaje
            })
        });

        console.log('Response status:', response.status);
        console.log('Response ok:', response.ok);

        const result = await response.json();

        console.log('Response body:', result);

        if (result.sent) {
            console.log('✅ WhatsApp enviado exitosamente:', result);
            return { success: true, messageId: result.id };
        } else {
            console.error('❌ Error al enviar WhatsApp:', result);
            return { success: false, error: result };
        }
    } catch (error) {
        console.error('❌❌ Error al enviar WhatsApp:', error);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
        return { success: false, error: error.message };
    }
}

// Función para generar mensaje de confirmación de reserva
function generarMensajeConfirmacion(reserva) {
    // Manejar diferentes nombres de campos
    const nombre = reserva.nombre || reserva.name || 'Cliente';
    const telefono = reserva.telefono || reserva.phone || 'No especificado';
    const fecha = reserva.fecha || reserva.date || new Date().toISOString().split('T')[0];
    const hora = reserva.hora || reserva.timeSlot || 'No especificado';

    // Manejar servicios (puede ser string o array)
    let servicio = 'No especificado';
    if (typeof reserva.servicio === 'string') {
        servicio = reserva.servicio;
    } else if (Array.isArray(reserva.services) && reserva.services.length > 0) {
        servicio = reserva.services.map(s => s.name || s).join(', ');
    }

    const fechaFormateada = new Date(fecha).toLocaleDateString('es-UY', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });

    return `✅ *RESERVA CONFIRMADA*

👤 *Cliente:* ${nombre}
💇 *Servicio:* ${servicio}
📅 *Fecha:* ${fechaFormateada}
⏰ *Hora:* ${hora}
📱 *Teléfono:* ${telefono}

🙏 Gracias por confiar en nosotros!

Si necesitas cancelar o modificar tu reserva, por favor contáctanos.`;
}

// Función para enviar confirmación de WhatsApp
async function enviarConfirmacionWhatsApp(reserva) {
    try {
        console.log('=== ENVIANDO CONFIRMACIÓN DE WHATSAPP ===');
        console.log('Datos de reserva:', reserva);

        // Buscar teléfono en ambos campos (phone y telefono)
        const telefono = reserva.telefono || reserva.phone;

        if (!telefono) {
            console.warn('⚠️ No hay teléfono para enviar WhatsApp');
            console.warn('Campos disponibles:', Object.keys(reserva));
            return { success: false, error: 'No hay teléfono' };
        }

        console.log('📱 Teléfono encontrado:', telefono);

        const mensaje = generarMensajeConfirmacion(reserva);
        console.log('Mensaje generado:', mensaje);

        const resultado = await enviarWhatsApp(telefono, mensaje);

        console.log('Resultado del envío:', resultado);

        return resultado;
    } catch (error) {
        console.error('❌❌ Error al enviar confirmación de WhatsApp:', error);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
        return { success: false, error: error.message };
    }
}

// Función para guardar configuración de WhatsApp
async function guardarConfiguracionWhatsApp(config) {
    try {
        if (!db) {
            throw new Error('Firestore no está inicializado');
        }
        await db.collection('config').doc('whatsapp').set({
            ...config,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        console.log('Configuración de WhatsApp guardada');
    } catch (error) {
        console.error('Error al guardar configuración de WhatsApp:', error);
        throw error;
    }
}

// Función para obtener configuración de WhatsApp
async function obtenerConfiguracionWhatsApp() {
    try {
        if (!db) {
            console.error('Firestore no está inicializado');
            return null;
        }
        const doc = await db.collection('config').doc('whatsapp').get();
        return doc.exists ? doc.data() : null;
    } catch (error) {
        console.error('Error al obtener configuración de WhatsApp:', error);
        return null;
    }
}

// Función para escuchar cambios en la configuración de WhatsApp
function escucharConfiguracionWhatsApp(callback) {
    try {
        if (!db) {
            console.error('Firestore no está inicializado');
            return () => {};
        }
        return db.collection('config').doc('whatsapp')
            .onSnapshot((doc) => {
                const data = doc.exists ? doc.data() : null;
                callback(data);
            }, (error) => {
                console.error('Error al escuchar configuración de WhatsApp:', error);
            });
    } catch (error) {
        console.error('Error al configurar escucha de WhatsApp:', error);
        return () => {};
    }
}

// Hacer funciones de WhatsApp disponibles globalmente
window.formatearNumeroWhatsApp = formatearNumeroWhatsApp;
window.enviarWhatsApp = enviarWhatsApp;
window.enviarConfirmacionWhatsApp = enviarConfirmacionWhatsApp;
window.generarMensajeConfirmacion = generarMensajeConfirmacion;
window.guardarConfiguracionWhatsApp = guardarConfiguracionWhatsApp;
window.obtenerConfiguracionWhatsApp = obtenerConfiguracionWhatsApp;
window.escucharConfiguracionWhatsApp = escucharConfiguracionWhatsApp;

console.log('✅ Funciones de WhatsApp cargadas y disponibles globalmente');