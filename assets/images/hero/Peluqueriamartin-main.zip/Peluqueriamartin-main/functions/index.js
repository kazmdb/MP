const functions = require('firebase-functions');
const admin = require('firebase-admin');
const axios = require('axios');

// Inicializar Firebase Admin
admin.initializeApp();

// Configuración de Ultramsg
const ULTRAMSG_CONFIG = {
    instanceId: 'instance174468',
    token: '22buqtstxo87neek',
    apiUrl: 'https://api.ultramsg.com'
};

// Función para formatear número de teléfono
function formatearNumero(numero) {
    let limpio = numero.replace(/[\s\-\(\)]/g, '');
    limpio = limpio.replace(/^\+/, '');

    if (!limpio.startsWith('598')) {
        limpio = '598' + limpio;
    }

    return limpio;
}

// Función para enviar mensaje de WhatsApp
async function enviarWhatsApp(numero, mensaje) {
    try {
        const numeroFormateado = formatearNumero(numero);
        const url = `${ULTRAMSG_CONFIG.apiUrl}/${ULTRAMSG_CONFIG.instanceId}/messages/chat`;

        const response = await axios.post(url, {
            token: ULTRAMSG_CONFIG.token,
            to: numeroFormateado,
            body: mensaje
        });

        return { success: response.data.sent, messageId: response.data.id };
    } catch (error) {
        console.error('Error al enviar WhatsApp:', error);
        return { success: false, error: error.message };
    }
}

// Función para generar mensaje de confirmación
function generarMensajeConfirmacion(reserva) {
    const nombre = reserva.nombre || reserva.name || 'Cliente';
    const telefono = reserva.telefono || reserva.phone || 'No especificado';
    const fecha = reserva.fecha || reserva.date || new Date().toISOString().split('T')[0];
    const hora = reserva.hora || reserva.timeSlot || 'No especificado';

    let servicio = 'No especificado';
    if (typeof reserva.servicio === 'string') {
        servicio = reserva.servicio;
    } else if (Array.isArray(reserva.services) && reserva.services.length > 0) {
        servicio = reserva.services.map(s => s.name || s).join(', ');
    }

    const fechaFormateada = new Date(fecha).toLocaleDateString('es-UY', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });

    return `✅ *RESERVA CONFIRMADA*

👤 *Cliente:* ${nombre}
💇 *Servicio:* ${servicio}
📅 *Fecha:* ${fechaFormateada}
⏰ *Hora:* ${hora}
📱 *Teléfono:* ${telefono}

🙏 Gracias por confiar en nosotros!

Si necesitas cancelar o modificar tu reserva, por favor contáctanos.`;
}

// Función para generar mensaje de recordatorio
function generarMensajeRecordatorio(reserva) {
    const nombre = reserva.nombre || reserva.name || 'Cliente';
    const fecha = reserva.fecha || reserva.date || new Date().toISOString().split('T')[0];
    const hora = reserva.hora || reserva.timeSlot || 'No especificado';

    let servicio = 'No especificado';
    if (typeof reserva.servicio === 'string') {
        servicio = reserva.servicio;
    } else if (Array.isArray(reserva.services) && reserva.services.length > 0) {
        servicio = reserva.services.map(s => s.name || s).join(', ');
    }

    const fechaFormateada = new Date(fecha).toLocaleDateString('es-UY', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });

    return `⏰ *RECORDATORIO DE TURNO*

👤 *Hola ${nombre}!*

Te recordamos que tienes un turno agendado:

💇 *Servicio:* ${servicio}
📅 *Fecha:* ${fechaFormateada}
⏰ *Hora:* ${hora}

📍 Te esperamos en Peluquería Martín.

Si no puedes asistir, por favor contáctanos para reprogramar.`;
}

// Cloud Function: Confirmación de reserva
exports.enviarConfirmacionReserva = functions.firestore
    .onDocumentCreated('reservas/{reservaId}', async (snap, context) => {
        try {
            const reserva = snap.data();
            console.log('Nueva reserva creada:', reserva);

            // Buscar teléfono en ambos campos
            const telefono = reserva.telefono || reserva.phone;

            if (!telefono) {
                console.log('No hay teléfono para enviar WhatsApp');
                return null;
            }

            // Generar y enviar mensaje
            const mensaje = generarMensajeConfirmacion(reserva);
            const resultado = await enviarWhatsApp(telefono, mensaje);

            if (resultado.success) {
                // Actualizar reserva con estado de WhatsApp
                await snap.ref.update({
                    whatsappEnviado: true,
                    whatsappEnviadoEn: admin.firestore.FieldValue.serverTimestamp()
                });
                console.log('WhatsApp enviado exitosamente para reserva:', context.params.reservaId);
            } else {
                console.error('Error al enviar WhatsApp:', resultado.error);
            }

            return null;
        } catch (error) {
            console.error('Error en enviarConfirmacionReserva:', error);
            return null;
        }
    });

// Cloud Function: Recordatorios automáticos
exports.enviarRecordatorios = functions.pubsub
    .schedule('0 * * * *')  // Cada hora en punto
    .timeZone('America/Montevideo')
    .onRun(async (context) => {
        try {
            const db = admin.firestore();
            const now = new Date();

            // Calcular fecha de mañana (24 horas desde ahora)
            const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
            const tomorrowStr = tomorrow.toISOString().split('T')[0];

            console.log('Buscando reservas para:', tomorrowStr);

            // Buscar reservas para mañana que no tengan recordatorio enviado
            const snapshot = await db.collection('reservas')
                .where('fecha', '==', tomorrowStr)
                .where('recordatorioEnviado', '==', false)
                .get();

            console.log('Reservas encontradas:', snapshot.size);

            const resultados = [];

            for (const doc of snapshot.docs) {
                const reserva = doc.data();
                const telefono = reserva.telefono || reserva.phone;

                if (!telefono) {
                    console.log('Reserva sin teléfono:', doc.id);
                    continue;
                }

                try {
                    const mensaje = generarMensajeRecordatorio(reserva);
                    const resultado = await enviarWhatsApp(telefono, mensaje);

                    if (resultado.success) {
                        await doc.ref.update({
                            recordatorioEnviado: true,
                            recordatorioEnviadoEn: admin.firestore.FieldValue.serverTimestamp()
                        });
                        console.log('Recordatorio enviado para reserva:', doc.id);
                        resultados.push({ reservaId: doc.id, success: true });
                    } else {
                        console.error('Error al enviar recordatorio:', resultado.error);
                        resultados.push({ reservaId: doc.id, success: false, error: resultado.error });
                    }
                } catch (error) {
                    console.error('Error al procesar reserva:', doc.id, error);
                    resultados.push({ reservaId: doc.id, success: false, error: error.message });
                }
            }

            console.log('Proceso de recordatorios completado:', resultados);
            return null;
        } catch (error) {
            console.error('Error en enviarRecordatorios:', error);
            return null;
        }
    });

// Cloud Function: Envío manual de WhatsApp
exports.enviarWhatsAppManual = functions.https.onCall(async (data, context) => {
    try {
        // Verificar autenticación
        if (!context.auth) {
            throw new functions.https.HttpsError(
                'unauthenticated',
                'Debes estar autenticado para enviar mensajes'
            );
        }

        const { numero, mensaje, tipo = 'general' } = data;

        if (!numero || !mensaje) {
            throw new functions.https.HttpsError(
                'invalid-argument',
                'Número y mensaje son requeridos'
            );
        }

        console.log('Envío manual solicitado:', { numero, tipo });

        const resultado = await enviarWhatsApp(numero, mensaje);

        if (resultado.success) {
            return {
                success: true,
                messageId: resultado.messageId,
                message: 'Mensaje enviado exitosamente'
            };
        } else {
            throw new functions.https.HttpsError(
                'internal',
                'Error al enviar mensaje: ' + resultado.error
            );
        }
    } catch (error) {
        console.error('Error en enviarWhatsAppManual:', error);
        throw new functions.https.HttpsError(
            'internal',
            error.message
        );
    }
});

// Cloud Function: Enviar recordatorio manual
exports.enviarRecordatorioManual = functions.https.onCall(async (data, context) => {
    try {
        // Verificar autenticación
        if (!context.auth) {
            throw new functions.https.HttpsError(
                'unauthenticated',
                'Debes estar autenticado para enviar recordatorios'
            );
        }

        const { reservaId } = data;

        if (!reservaId) {
            throw new functions.https.HttpsError(
                'invalid-argument',
                'ID de reserva es requerido'
            );
        }

        console.log('Recordatorio manual solicitado para reserva:', reservaId);

        const db = admin.firestore();
        const doc = await db.collection('reservas').doc(reservaId).get();

        if (!doc.exists) {
            throw new functions.https.HttpsError(
                'not-found',
                'Reserva no encontrada'
            );
        }

        const reserva = doc.data();
        const telefono = reserva.telefono || reserva.phone;

        if (!telefono) {
            throw new functions.https.HttpsError(
                'invalid-argument',
                'La reserva no tiene teléfono'
            );
        }

        const mensaje = generarMensajeRecordatorio(reserva);
        const resultado = await enviarWhatsApp(telefono, mensaje);

        if (resultado.success) {
            // Actualizar reserva
            await doc.ref.update({
                recordatorioEnviado: true,
                recordatorioEnviadoEn: admin.firestore.FieldValue.serverTimestamp()
            });

            return {
                success: true,
                messageId: resultado.messageId,
                message: 'Recordatorio enviado exitosamente'
            };
        } else {
            throw new functions.https.HttpsError(
                'internal',
                'Error al enviar recordatorio: ' + resultado.error
            );
        }
    } catch (error) {
        console.error('Error en enviarRecordatorioManual:', error);
        throw new functions.https.HttpsError(
            'internal',
            error.message
        );
    }
});
}